//
//  Segue.swift
//  Segue
//
//  Created by iOS 15 Programming on 13/08/2021.
//

import Foundation
import UserNotifications

enum Segue: String {
    case showDetail
    case showRating
    case showReview
    case showAllReviews
    case restaurantList
    case locationList
    case showPhotoReview
    case showPhotoFilter
}

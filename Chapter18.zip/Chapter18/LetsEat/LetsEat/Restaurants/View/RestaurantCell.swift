//
//  RestaurantCell.swift
//  LetsEat
//
//  Created by iOS 15 Programming on 05/07/2021.
//

import UIKit

class RestaurantCell: UICollectionViewCell {
    
    @IBOutlet var lblTitle: UILabel!
    
    @IBOutlet var lblCuisine: UILabel!
    
    
    @IBOutlet var imgRestaurant: UIImageView!
}

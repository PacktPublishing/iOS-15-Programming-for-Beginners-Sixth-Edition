//
//  ExploreDataManager.swift
//  ExploreDataManager
//
//  Created by iOS 15 Programming on 13/08/2021.
//

import Foundation

class ExploreDataManager: DataManager {
    
    fileprivate var items: [ExploreItem] = []
    
    func fetch() {
        for data in load(file: "ExploreData") {
            items.append(ExploreItem(dict: data))
        }
    }
    
    func numberOfExploreItems() -> Int {
        items.count
    }
    
    func exploreItem(at index: IndexPath) -> ExploreItem {
        items[index.item]
    }
}

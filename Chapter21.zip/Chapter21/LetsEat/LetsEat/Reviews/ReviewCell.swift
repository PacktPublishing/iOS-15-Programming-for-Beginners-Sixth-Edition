//
//  ReviewCell.swift
//  LetsEat
//
//  Created by iOS 15 Programming on 09/07/2021.
//

import UIKit

class ReviewCell: UICollectionViewCell {
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblDate: UILabel!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblReview: UILabel!
    @IBOutlet var ratingsView: RatingsView!
    
}

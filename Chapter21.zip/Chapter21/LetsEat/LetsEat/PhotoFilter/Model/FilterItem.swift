//
//  FilterItem.swift
//  FilterItem
//
//  Created by iOS 15 Programming on 15/08/2021.
//

import Foundation

class FilterItem: NSObject {
    
    let filter: String
    let name: String
    
    init(dict: [String:AnyObject]) {
        name = dict["name"] as! String
        filter = dict["filter"] as! String
    }
}

//
//  FilterManager.swift
//  FilterManager
//
//  Created by iOS 15 Programming on 15/08/2021.
//

import Foundation

class FilterManager: DataManager {
    
    func fetch(completionHandler: (_ items:[FilterItem]) -> Void) {
        var items: [FilterItem] = []
        for data in load(file: "FilterData") {
            items.append(FilterItem(dict: data))
        }
        completionHandler(items)
    }
}

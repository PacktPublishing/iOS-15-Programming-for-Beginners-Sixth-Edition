//
//  ExploreCell.swift
//  LetsEat
//
//  Created by iOS 15 Programming on 30/06/2021.
//

import UIKit

class ExploreCell: UICollectionViewCell {
    
    @IBOutlet var lblName: UILabel!
    @IBOutlet var imgExplore: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imgExplore.layer.cornerRadius = 9
        imgExplore.layer.masksToBounds = true
    }
}

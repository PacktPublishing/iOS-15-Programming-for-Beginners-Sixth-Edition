//
//  ExploreHeaderView.swift
//  ExploreHeaderView
//
//  Created by iOS 15 Programming on 14/08/2021.
//

import UIKit

class ExploreHeaderView: UICollectionReusableView {
        
    @IBOutlet var lblLocation: UILabel!
}

//
//  ExploreHeaderView.swift
//  LetsEat
//
//  Created by iOS 15 Programming on 07/11/2021.
//

import UIKit

class ExploreHeaderView: UICollectionReusableView {
    
    @IBOutlet var locationLabel: UILabel!
    
}

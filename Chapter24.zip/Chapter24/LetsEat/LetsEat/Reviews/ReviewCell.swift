//
//  ReviewCell.swift
//  ReviewCell
//
//  Created by iOS 15 Programming on 15/08/2021.
//

import UIKit

class ReviewCell: UICollectionViewCell {
    
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblDate: UILabel!
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblReview: UILabel!
    @IBOutlet var ratingsView: RatingsView!
    
}

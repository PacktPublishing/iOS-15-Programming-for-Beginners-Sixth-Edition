//
//  RestaurantCell.swift
//  RestaurantCell
//
//  Created by iOS 15 Programming on 14/08/2021.
//

import UIKit

class RestaurantCell: UICollectionViewCell {
    
    @IBOutlet var lblTitle: UILabel!
    
    @IBOutlet var lblCuisine: UILabel!

    @IBOutlet var imgRestaurant: UIImageView!
    
}

//
//  ExploreCell.swift
//  ExploreCell
//
//  Created by iOS 15 Programming on 13/08/2021.
//

import UIKit

class ExploreCell: UICollectionViewCell {
    
    @IBOutlet var imgExplore: UIImageView!
    @IBOutlet var lblName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imgExplore.layer.cornerRadius = 9
        imgExplore.layer.masksToBounds = true
    }
    
}

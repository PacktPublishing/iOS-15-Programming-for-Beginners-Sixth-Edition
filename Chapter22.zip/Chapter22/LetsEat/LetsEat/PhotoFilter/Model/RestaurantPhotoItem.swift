//
//  RestaurantPhotoItem.swift
//  LetsEat
//
//  Created by iOS 15 Programming on 09/07/2021.
//

import UIKit
struct RestaurantPhotoItem {
    var photo: UIImage?
    var date: Date?
    var restaurantID: Int?
    var uuid = UUID().uuidString
    var photoData: Data {
        guard let image = photo else {
            return Data()
        }
        return Data(image.pngData()!)
    }
}

extension RestaurantPhotoItem {
    init(restaurantPhoto: RestaurantPhoto) {
        self.restaurantID = Int(restaurantPhoto.restaurantID)
        if let restPhoto = restaurantPhoto.photo {
            self.photo = UIImage(data: restPhoto, scale: 1.0)
        }
        if let uuid = restaurantPhoto.uuid {
            self.uuid = uuid
        }
        if let reviewDate = restaurantPhoto.date {
            self.date = reviewDate
        }
    }
}

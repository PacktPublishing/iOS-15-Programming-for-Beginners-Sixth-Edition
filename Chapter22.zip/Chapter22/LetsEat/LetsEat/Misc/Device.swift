//
//  Device.swift
//  LetsEat
//
//  Created by iOS 15 Programming on 12/07/2021.
//

import UIKit

enum Device {
    static var isPhone: Bool {
        return UIDevice.current.userInterfaceIdiom == .phone
    }
    static var isPad: Bool {
        return UIDevice.current.userInterfaceIdiom == .pad  
    }
}

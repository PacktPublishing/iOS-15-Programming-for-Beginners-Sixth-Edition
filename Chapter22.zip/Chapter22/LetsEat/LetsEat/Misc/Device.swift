//
//  Device.swift
//  Device
//
//  Created by iOS 15 Programming on 15/08/2021.
//

import UIKit

enum Device {
    static var isPhone: Bool {
        return UIDevice.current.userInterfaceIdiom == .phone
    }
    static var isPad: Bool {
        return UIDevice.current.userInterfaceIdiom == .pad  
    }
}

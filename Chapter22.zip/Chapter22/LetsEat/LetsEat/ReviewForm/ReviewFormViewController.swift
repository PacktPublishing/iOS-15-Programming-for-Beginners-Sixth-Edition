//
//  ReviewFormViewController.swift
//  LetsEat
//
//  Created by iOS 15 Programming on 07/07/2021.
//

import UIKit

class ReviewFormViewController: UITableViewController {
    
    var selectedRestaurantID: Int?
    
    @IBOutlet var ratingsView: RatingsView!
    @IBOutlet var tfTitle: UITextField!
    @IBOutlet var tfName: UITextField!
    @IBOutlet var tvReview: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(selectedRestaurantID as Any)
    }
}

private extension ReviewFormViewController {
    
    @IBAction func onSaveTapped(_ sender: Any) {
        var item = ReviewItem()
        item.name = tfName.text
        item.title = tfTitle.text
        item.customerReview = tvReview.text
        item.restaurantID = selectedRestaurantID
        item.rating = Double(ratingsView.rating)
        CoreDataManager.shared.addReview(item)
        dismiss(animated: true, completion: nil)
    }
    
}

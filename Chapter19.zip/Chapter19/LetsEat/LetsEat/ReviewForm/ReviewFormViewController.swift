//
//  ReviewFormViewController.swift
//  LetsEat
//
//  Created by iOS 15 Programming on 07/07/2021.
//

import UIKit

class ReviewFormViewController: UITableViewController {
    
    @IBOutlet var ratingsView: RatingsView!
    @IBOutlet var tfTitle: UITextField!
    @IBOutlet var tfName: UITextField!
    @IBOutlet var tvReview: UITextView!
    
    @IBAction func onSaveTapped(_ sender: Any) {
        print(ratingsView.rating)
        print(tfTitle.text as Any)
        print(tfName.text as Any)
        print(tvReview.text as Any)
        dismiss(animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }

 

}

//
//  ExploreDataManager.swift
//  ExploreDataManager
//
//  Created by iOS 15 Programming on 13/08/2021.
//

import Foundation

class ExploreDataManager {
    
    fileprivate var items: [ExploreItem] = []
    
    func fetch() {
        for data in loadData() {
            items.append(ExploreItem(dict: data))
        }
    }
    
    fileprivate func loadData() -> [[String:AnyObject]] {
        guard let path = Bundle.main.path(forResource: "ExploreData", ofType: "plist"), let items = NSArray(contentsOfFile: path) else {
            return [[:]]
        }
        return items as! [[String:AnyObject]]
    }
    
    func numberOfExploreItems() -> Int {
        items.count
    }
    
    func exploreItem(at index: IndexPath) -> ExploreItem {
        items[index.item]
    }
}

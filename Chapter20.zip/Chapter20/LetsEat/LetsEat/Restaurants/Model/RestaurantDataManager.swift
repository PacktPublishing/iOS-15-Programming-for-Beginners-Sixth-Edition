//
//  RestaurantDataManager.swift
//  RestaurantDataManager
//
//  Created by iOS 15 Programming on 14/08/2021.
//

import Foundation

class RestaurantDataManager {
    
    private var items: [RestaurantItem] = []
    func fetch(location: String, selectedCuisine: String = "All", completionHandler: (_ items: [RestaurantItem]) -> Void) {
        if let file = Bundle.main.url(forResource: location, withExtension: "json") {
            do {
                let data = try Data(contentsOf: file)
                let restaurants = try JSONDecoder().decode([RestaurantItem].self, from: data)
                if selectedCuisine != "All" {
                    items = restaurants.filter { ($0.cuisines.contains(selectedCuisine))
                    }
                }
                else { items = restaurants }
            } catch {
                print("there was an error \(error)")
            }
        }
        completionHandler(items)
    }
    
    func numberOfRestaurantItems() -> Int {
        items.count
    }
    
    func restaurantItem(at index: IndexPath) -> RestaurantItem {
        items[index.item]
    }
}

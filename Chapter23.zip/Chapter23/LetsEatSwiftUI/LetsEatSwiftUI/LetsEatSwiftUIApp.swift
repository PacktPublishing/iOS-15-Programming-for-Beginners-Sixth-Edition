//
//  LetsEatSwiftUIApp.swift
//  LetsEatSwiftUI
//
//  Created by iOS 15 Programming on 14/12/2021.
//

import SwiftUI

@main
struct LetsEatSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  LetsEatSwiftUIApp.swift
//  LetsEatSwiftUI
//
//  Created by iOS 15 Programming on 15/07/2021.
//

import SwiftUI

@main
struct LetsEatSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
